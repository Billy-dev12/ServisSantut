<?php
// Periksa apakah request ini berasal dari AJAX
if (isset($_GET['action']) && $_GET['action'] == 'refresh_table') {
    require '../config/koneksi.php';

    // Ambil data tiket berdasarkan role user (admin, teknisi, atau pelanggan)
    $user_id = $_SESSION['user_id'];
    if ($_SESSION['role'] == 'admin') {
        // Jika admin, ambil semua tiket
        $query = "SELECT * FROM tiket_servis";
    } else if ($_SESSION['role'] == 'teknisi') {
        // Jika teknisi, ambil tiket yang ditugaskan ke teknisi
        $query = "SELECT * FROM tiket_servis WHERE teknisi_id='$user_id'";
    } else if ($_SESSION['role'] == 'pelanggan') {
        // Jika pelanggan, hanya tampilkan tiket yang dimiliki pelanggan
        $query = "SELECT * FROM tiket_servis WHERE user_id='$user_id'";
    }

    $result = $koneksi->query($query);

    if ($result->num_rows > 0) {
        echo '<table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr>
                        <th>No. Tiket</th>
                        <th>Perangkat</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>';

        while ($row = $result->fetch_assoc()) {
            echo '<tr>
                    <td>#' . str_pad($row['id'], 4, '0', STR_PAD_LEFT) . '</td>
                    <td>' . $row['device_type'] . '</td>
                    <td>' . ucfirst($row['status']) . '</td>
                    <td>' . date('d/m/Y', strtotime($row['tanggal_dibuat'])) . '</td>
                    <td>
                        <a href="detail_tiket.php?id=' . $row['id'] . '" class="btn btn-sm btn-primary">
                            <i class="fas fa-eye"></i> Detail
                        </a>
                    </td>
                </tr>';
        }

        echo '</tbody></table>';
    } else {
        echo '<div class="alert alert-info">Tidak ada tiket untuk ditampilkan.</div>';
    }
}
?>
