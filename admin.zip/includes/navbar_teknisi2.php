<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teknisi - Servis Komputer</title>
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --secondary-color: #f8f9fc;
            --dark-color: #5a5c69;
        }
        
        body {
            font-family: 'Nunito', sans-serif;
            background-color: #f8f9fc;
        }

        /* Navbar utama */
        .navbar-teknisi {
            background: white;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            height: 60px;
        }
        
        .navbar-brand {
            font-weight: 800;
            color: var(--primary-color) !important;
        }
        
        .navbar-brand img {
            height: 40px;
        }
        
        /* Sidebar */
        .sidebar {
            width: 220px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: linear-gradient(180deg, var(--primary-color) 0%, #224abe 100%);
            color: white;
            z-index: 100;
            padding-top: 70px;
            transition: all 0.3s;
        }
        
        .sidebar-brand {
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 1.1rem;
            position: fixed;
            top: 0;
            left: 0;
            width: 220px;
            background: rgba(0, 0, 0, 0.1);
            z-index: 101;
        }
        
        .sidebar-item {
            padding: 12px 20px;
            color: rgba(255, 255, 255, 0.8);
            display: block;
            text-decoration: none;
            border-left: 3px solid transparent;
            transition: all 0.3s;
            margin: 5px 10px;
            border-radius: 5px;
        }
        
        .sidebar-item:hover, 
        .sidebar-item.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            border-left: 3px solid white;
            text-decoration: none;
        }
        
        .sidebar-item i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main content */
        .main-content {
            margin-left: 220px;
            padding: 20px;
            min-height: calc(100vh - 60px);
        }

        /* User dropdown */
        .dropdown-menu {
            border: none;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .user-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-220px);
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-user-cog me-2"></i>
            <span>Panel Teknisi</span>
        </div>
        <!-- Sidebar items can go here -->
    </div>

    <!-- Top Navigation -->
    <nav class="navbar navbar-teknisi navbar-expand navbar-light fixed-top">
        <div class="container-fluid">
            <!-- Toggle sidebar button (mobile) -->
            <button class="btn btn-link d-md-none mr-3" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <!-- Brand -->
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-tools me-2"></i>
                <span class="d-none d-md-inline">ServisKomputer</span>
            </a>

            <!-- Navbar items -->
            <ul class="navbar-nav ms-auto">
                <!-- Notifications and User dropdown here -->
            </ul>
        </div>
    </nav>

    <!-- Main content wrapper -->
    <div class="main-content">
        <div class="container-fluid pt-4">
            <!-- Konten halaman akan dimasukkan di sini -->
        </div>
    </div>

    <!-- JavaScript untuk mengaktifkan sidebar di mobile -->
    <script>
        // Toggle sidebar pada mobile
        document.getElementById('sidebarToggle').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    </script>

</body>
</html>
