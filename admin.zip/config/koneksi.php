<?php
$host = 'localhost';  // Bisa diganti dengan alamat IP atau hostname jika di hosting
$user = 'billysto_billahi';
$password = 'hackaku12345';
$database = 'billysto_servis_komputer_db';
$port = 3306;  // Pastikan port yang benar jika tidak menggunakan default

// Membuat koneksi dengan port
$koneksi = new mysqli($host, $user, $password, $database, $port);

// Mengecek koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

// Fungsi sederhana untuk amankan input
function bersihkan($data) {
    global $koneksi;
    return $koneksi->real_escape_string(strip_tags(trim($data)));
}

// Mulai session
session_start();
?>
